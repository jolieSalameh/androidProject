package com.example.project;

public class ItemsOrder {
   public String nameRoll;
   public String amount;

    public ItemsOrder(String nameRoll, String amount) {
        this.nameRoll = nameRoll;
        this.amount = amount;
    }

    public String getNameRoll() {
        return nameRoll;
    }

    public String getAmount() {
        return amount;
    }

    public void setNameRoll(String nameRoll) {
        this.nameRoll = nameRoll;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
