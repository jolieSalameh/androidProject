package com.example.project;

public class Client {
   public String firstName;
   public String lastName;
   public String phoneNumber;
   public String city;

    public Client(String firstName, String lastName, String phoneNumber, String city) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.city = city;
    }
}
